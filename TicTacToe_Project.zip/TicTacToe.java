import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;


/**
 * This class represents a Tic Tac Toe game application.
 */
public class TicTacToe 
{  
   private GameInitializer gameInitializer;
   private GameLogicHandler gameLogicHandler;

   public TicTacToe() 
   {
     // Initialize GameInitializer and GameLogicHandler objects
      gameLogicHandler = new GameLogicHandler(this, null);
      gameInitializer = new GameInitializer(this, gameLogicHandler);
   
    // Set the GameLogicHandler object in GameInitializer
      gameInitializer.setGameLogicHandler(gameLogicHandler);
    // Set the GameInitializer object in GameLogicHandler
      gameLogicHandler.setGameInitializer(gameInitializer);
   }
   
   public void StartGame()
   {
      gameInitializer.startNewGame();
   }
   
   /**
    * Main method to start the game.
    *
    * @param args Command-line arguments
    */
   public static void main(String[] args) 
   {     
      TicTacToe ticTacToe = new TicTacToe();
      
      ticTacToe.StartGame();
   }

}