import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

/**
 * Custom MouseListener for handling button clicks in the Tic Tac Toe game.
 */
public class ButtonMouseListener implements MouseListener 
{
   private GameLogicHandler gameLogicHandler;
   
   /**
   * Constructor to initialize player radio buttons.
   */
   public ButtonMouseListener( GameLogicHandler gameLogicHandler)
   {       
           this.gameLogicHandler = gameLogicHandler;
   }
   
   /**
   * Handles the mouseClicked event when a button is clicked.
   * 
   * @param e The MouseEvent object representing the mouse click event.
   */
   public void mouseClicked(MouseEvent e) 
   {
      JButton button = (JButton) e.getSource();
      
      if ( !button.getText().equals("") )
      {
         gameLogicHandler.GameMenue(button);
      }
      
      else if ( button.getText().equals("") )
      {  
         // Retrieve the index from the clicked button's client property
            int buttonIndex = (int) button.getClientProperty("index");
         
         gameLogicHandler.makePlayerMove(button, buttonIndex );
      }
   }
   
   public void mousePressed(MouseEvent e) {}
   public void mouseReleased(MouseEvent e) {}
   public void mouseEntered(MouseEvent e) {}
   public void mouseExited(MouseEvent e) {}
}
