import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class GameLogicHandler 
{
   private TicTacToe ticTacToe;
   private GameInitializer gameInitializer;
   
   public GameLogicHandler(TicTacToe ticTacToe, GameInitializer gameInitializer )
   {
      this.ticTacToe = ticTacToe;
      this.gameInitializer = gameInitializer;
   }
   
   public void setGameInitializer(GameInitializer gameInitializer) 
   {
      this.gameInitializer = gameInitializer;
   }
   
   public void  makePlayerMove(JButton button, int index)
   {  
      JRadioButton player1RadioButton = gameInitializer.getPlayer1RadioButton();
      JRadioButton player2RadioButton = gameInitializer.getPlayer2RadioButton();
   
      if (!button.isEnabled()) 
      {
         System.out.println("Button is already disabled");
         return; // Prevent action if button is already disabled
      }
   
      if ( player1RadioButton.isSelected() ) 
      {
         // Player 1's move
         gameInitializer.getButtons().get(index).setFont(new Font(Font.DIALOG, Font.PLAIN, 100));
         gameInitializer.getButtons().get(index).setText("O");
         gameInitializer.getButtons().get(index).setBackground(Color.RED);
         gameInitializer.getButtons().get(index).setEnabled(false); // Disable this button after marking
         
         if ( !findWinner( gameInitializer.getButtons() ) ) 
         {
            // Toggle turn if no winner
            player1RadioButton.setSelected(false);
            player2RadioButton.setSelected(true);
         }
      } 
      
      else if (player2RadioButton.isSelected() && !player2RadioButton.getText().equals("Computer") ) 
      {
         // Player 2's or Computer's move
         gameInitializer.getButtons().get(index).setFont(new Font(Font.DIALOG, Font.PLAIN, 100));
         gameInitializer.getButtons().get(index).setText("X");
         gameInitializer.getButtons().get(index).setBackground(Color.BLUE);
         gameInitializer.getButtons().get(index).setEnabled(false); // Disable this button after marking
         
         if ( !findWinner( gameInitializer.getButtons() ) ) 
         {
            // Toggle turn if no winner
            player1RadioButton.setSelected(true);
            player2RadioButton.setSelected(false);
         }
      }
   
   // Check if there is a winner or if the game should continue
      if ( !findWinner( gameInitializer.getButtons() ) )
      {
         // If it is Computer's turn and no winner was found, let the computer make a move
         if (player2RadioButton.getText().equals("Computer") && player2RadioButton.isSelected()) 
         {
            makeComputerMove();
         }
      } 
      
      else
      {
      // Handle end of game and display winner
         gameInitializer.getButtonContainer().removeAll();
         gameInitializer.getButtons().clear();
         gameInitializer.winnerFrame();
      }
   }

 /**

Makes a move for the computer player by selecting a random enabled button on the game board.
Simulates a mouse click on the randomly selected button to make the move.
*/
   private void makeComputerMove( ) 
   {
   
      Random random = new Random();
      
      int index;
      do 
      {
         index = random.nextInt(9);
         
      } while ( !gameInitializer.getButtons().get(index).isEnabled() );
     
      //buttons.get(index).doClick();
      
      gameInitializer.getButtons().get(index).setText("X");
      gameInitializer.getButtons().get(index).setFont(new Font(Font.DIALOG, Font.PLAIN, 100));
      
      // Update the button list with the modified button
      gameInitializer.getButtons().get(index).setEnabled(false);
      
      gameInitializer.getPlayer1RadioButton().setSelected(true);
      gameInitializer.getPlayer2RadioButton().setSelected(false);
   }


   /**
 * Checks for a winning condition or a draw in the Tic Tac Toe game.
 * @param buttons The list of buttons representing the game board.
 * @return True if there is a winner or a draw, false otherwise.
 */
   public boolean findWinner(ArrayList<JButton> buttons) {
    // Check rows
      for (int i = 0; i < 3; i++) {
         int rowIndex = i * 3;
         if (!buttons.get(rowIndex).getText().isEmpty() &&
            buttons.get(rowIndex).getText().equals(buttons.get(rowIndex + 1).getText()) &&
            buttons.get(rowIndex).getText().equals(buttons.get(rowIndex + 2).getText())) {
            return true; // Row win
         }
      }
   
    // Check columns
      for (int i = 0; i < 3; i++) {
         if (!buttons.get(i).getText().isEmpty() &&
            buttons.get(i).getText().equals(buttons.get(i + 3).getText()) &&
            buttons.get(i).getText().equals(buttons.get(i + 6).getText())) {
            return true; // Column win
         }
      }
   
    // Check diagonals
      if (!buttons.get(0).getText().isEmpty() &&
        buttons.get(0).getText().equals(buttons.get(4).getText()) &&
        buttons.get(0).getText().equals(buttons.get(8).getText())) {
         return true; // Diagonal (top-left to bottom-right) win
      }
   
      if (!buttons.get(2).getText().isEmpty() &&
        buttons.get(2).getText().equals(buttons.get(4).getText()) &&
        buttons.get(2).getText().equals(buttons.get(6).getText())) {
         return true; // Diagonal (top-right to bottom-left) win
      }
   
    // Check for a draw
      for (int i = 0; i < 9; i++) 
      {
         if ( !buttons.get(i).isEnabled() && i == 8)
         {
            System.out.println("i = " + i + " disabled false" );
         }
         
         else
         {
            System.out.println("i = " + i + " enabled true");
         }
         
         if ( !buttons.get(i).isEnabled() && i == 8)
         {
         System.out.println("draw");
            gameInitializer.draw = true;
            return true;
         } 
         
         else
         {
            gameInitializer.draw = false;
            return false;
         }
      }
      
      return false; // Draw or continue game
   }
    
   
   public void GameMenue(JButton button)
   {    
      if ( button.getText().equals( gameInitializer.getPlayerVsPlayer().getText() ) )
      {  
         gameInitializer.getPlayer1RadioButton().setText("Player 1");
         gameInitializer.getPlayer2RadioButton().setText("Player 2");
         gameInitializer.getButtonContainer().removeAll();
         gameInitializer.initializeGUI();
      } 
         
      else if( button.getText().equals( gameInitializer.getPlayerVsComputer().getText() ) )
      {
         gameInitializer.getPlayer1RadioButton().setText("Player 1");
         gameInitializer.getPlayer2RadioButton().setText("Computer");
         gameInitializer.getButtonContainer().removeAll();
         gameInitializer.initializeGUI();
      }
         
      else if (button.getText().equals( gameInitializer.getPlayAgain().getText() ) ) 
      {
          // Restart the game
         gameInitializer.getButtonContainer().removeAll();
         gameInitializer.startNewGame();
      } 
         
      else if (button.getText().equals("Exit game")) 
      {
            // Exit the game
         System.exit(0);
      }
   }
}