import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class GameInitializer
{
   private TicTacToe ticTacToe;
   private GameLogicHandler gameLogicHandler;
 

   GameInitializer(TicTacToe ticTacToe , GameLogicHandler gameLogicHandler)
   {
      this.ticTacToe = ticTacToe;
      this.gameLogicHandler = gameLogicHandler;    
   }
   
   public void setGameLogicHandler(GameLogicHandler gameLogicHandler) 
   {
      this.gameLogicHandler = gameLogicHandler;
   }
   
   private JFrame frame = new JFrame("Tic Tac Toe");
   
   /** Button for selecting player 1 vs player 2 mode. */
   private  JButton playerVsPlayer = new JButton("");
   
   /** Button for selecting player 1 vs Computer mode. */
   private  JButton playerVsComputer = new JButton("");
   
   /** Represents the container for holding buttons and other components. */
   private Container buttonContainer = new Container();
   
   /** Represents the list of 9 buttons that are used as placeholders for X or O signs in the game. */
   private ArrayList<JButton> buttons = new ArrayList<>();
   
   /** Radio button for selecting Player 1. */
   private JRadioButton player1RadioButton = new JRadioButton("");
   
   /**Radio button for selecting Player 2 or computer.*/
   private JRadioButton player2RadioButton = new JRadioButton("");
   
   private JButton playAgain = new JButton("");
   private JButton exitGame = new JButton("");
   
   public  boolean draw = false;
   public boolean getDraw()
   {
      return draw;
   }
   
   public JRadioButton getPlayer1RadioButton()
   {
      return player1RadioButton;
   }
   
   public JRadioButton getPlayer2RadioButton()
   {
      return player2RadioButton;
   }
   
   public ArrayList<JButton> getButtons() 
   {
      return buttons;
   }
   
   public Container getButtonContainer()
   {
      return buttonContainer;
   }
   
   public JButton getPlayAgain()
   {
      return playAgain;
   }
   
   public JButton getPlayerVsComputer()
   {
      return playerVsComputer;
   }
   
   public JButton getPlayerVsPlayer()
   {
      return playerVsPlayer;
   }
   
   /**
    * Initializes the game window for selecting game mode.
    */
   public void startNewGame()
   {
      createFrame(); // Create the main frame  
         
      gameMode(); // Setup the game mode selection screen
      
      // Update the layout of the button container to reflect any changes
      buttonContainer.revalidate();
      // Repaint the button container to ensure it is visually updated
      buttonContainer.repaint();
   
      frame.setVisible(true); // Make the main frame visible   
   }
   
   /**
    * Creates the main frame of the game.
    * @return The created JFrame object
    */
   public JFrame createFrame() 
   {
      frame.setSize(600, 600); // Set frame size
      frame.setResizable(true); // Allow frame resizing
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set default close operation
      return frame; // Return the created frame
   }
   
   /**
    * Sets up the game mode selection screen with buttons for choosing between
    * (player 1 vs player 2) and (player vs computer) modes.
    */
   public void gameMode()
   {  
      // Create buttons for selecting between (Player 1 vs Player 2) and (Player vs Computer)
      playerVsPlayer.setText("Player 1 vs Player 2");
      playerVsComputer.setText("Player vs Computer");
      
      // Add mouse listener to the buttons
      playerVsPlayer.addMouseListener(new ButtonMouseListener( gameLogicHandler ));
      playerVsComputer.addMouseListener(new ButtonMouseListener( gameLogicHandler ));
         
      // Set font and collor for the buttons
      playerVsPlayer.setFont(new Font(Font.DIALOG, Font.PLAIN, 50));
      playerVsComputer.setFont(new Font(Font.DIALOG, Font.PLAIN, 50));
      
      playerVsPlayer.setBackground(new Color(0, 255, 243));
      playerVsComputer.setBackground(new Color(0, 255, 243));
      
      // Set layout for the button container, 2 rows and 1 column
      buttonContainer.setLayout(new GridLayout(2, 1));
      
      // Add selection buttons to the container
      buttonContainer.add(playerVsPlayer);
      buttonContainer.add(playerVsComputer);
      
      // Update the layout of the button container to reflect any changes
      buttonContainer.revalidate();
      // Repaint the button container to ensure it is visually updated
      buttonContainer.repaint();
      // Add the button container to the main frame
      frame.add(buttonContainer, BorderLayout.CENTER);
   }

   /**
    * Initializes the game components after selecting game mode,
    * such as game board and players.
    */
   public void initializeGUI()
   { 
      // Set layout for the game board
      buttonContainer.setLayout(new GridLayout(3, 3));
      
      // call method to create the game board buttons
      createButtons();
      
      // call method to create selection panel between players
      SelectionPanel();
      
      // Update the layout of the button container to reflect any changes
      buttonContainer.revalidate();
      // Repaint the button container to ensure it is visually updated
      buttonContainer.repaint(); 
      // Add the game board to the main frame   
      frame.add(buttonContainer, BorderLayout.CENTER);
   }
   
   /**
    * Creates and initializes the buttons for the game board.
    * Iterates through 9 times to create buttons, adds them to the button container,
    * and attaches a mouse listener to each button.
    */
   public void createButtons()
   {
   
      // foor loop iterates 9 time to create 9 buttons 
      for (int i = 0; i < 9; i++) 
      {
         // Create a new button with no text
         JButton button = new JButton(""); 
         
            button.putClientProperty("index", i); // Associate button with its index
         
         // Add the button to the list of buttons
         buttons.add(button);
         
         // Add the button to the button container
         buttonContainer.add(buttons.get(i)); 
         
         // Attach a mouse listener to the button
         buttons.get(i).addMouseListener(new ButtonMouseListener( gameLogicHandler )); 
         
         // set the for the button 
         button.setBackground(new Color(0, 255, 243));
      }
   }

   /**
    * This method creates radio buttons for selecting between Player 1 and Player 2.
    * The panel is added to the top of the frame.
    */
   public void SelectionPanel()
   {
      // Initialize player selection radio buttons player 1 is selected by difault  
      player1RadioButton.setSelected(true);
      player2RadioButton.setSelected(false);
   
      // Create a button group to ensure only one player can be selected at a time
      ButtonGroup selectedPlayer = new ButtonGroup();
      JPanel radioPanel = new JPanel();
   
      // Create a panel to hold the radio buttons and score labels
      selectedPlayer.add(player1RadioButton);
      selectedPlayer.add(player2RadioButton);
   
      
      // Add the radio buttons to the button group
      radioPanel.add(player1RadioButton);
      radioPanel.add(player2RadioButton);
     
      // Add the player selection panel to the top of the frame
      frame.add(radioPanel, BorderLayout.NORTH);
   }

   /**
    * Displays the frame showing the winner or draw result of the Tic Tac Toe game.
    */
   public void winnerFrame()
   {
      // Set the layout to BorderLayout
      buttonContainer.setLayout(new GridLayout(3, 1));
      
      // Create buttons for result, play again, and exit game
      JButton result = new JButton();
      
      // Set text and appearance based on game result   
      if(player1RadioButton.isSelected() && !draw)
      {  
         // set result text to Winner: player 1
         result.setText( "Winner:" + player1RadioButton.getText() );
         
         // set result size and background color to Red
         result.setFont(new Font(Font.DIALOG, Font.PLAIN, 40));
         result.setBackground(Color.RED);
      }
         
      else if (player2RadioButton.isSelected() && !draw)
      { 
         // set result text to Winner: player 2
         result.setText( "Winner:" + player2RadioButton.getText() );
         
         // set result text size and background color to Blue
         result.setFont(new Font(Font.DIALOG, Font.PLAIN, 40));
         result.setBackground(Color.BLUE);
      }
      
      else 
      {  
         // set result text to Draw
         result.setText( "Draw");
         
         // set result text size and color
         result.setFont(new Font(Font.DIALOG, Font.PLAIN, 40));
         result.setBackground(new Color(0, 255, 243)); 
      }
   
      // Set text buttons      
      playAgain.setText("Play again");
      exitGame.setText("Exit game");
      
      // set font to the buttons
      playAgain.setFont(new Font(Font.DIALOG, Font.PLAIN, 40));
      exitGame.setFont(new Font(Font.DIALOG, Font.PLAIN, 40));
      
      // set color to the buttons
      playAgain.setBackground(new Color(156, 242, 87));
      exitGame.setBackground(new Color(0, 255, 243));
      
      //attach mouse Listiner to the buttons
      playAgain.addMouseListener(new ButtonMouseListener( gameLogicHandler ));
      exitGame.addMouseListener(new ButtonMouseListener( gameLogicHandler ));
                  
      // Add the Buttons result, playAgain, exitGame to the contanier
      buttonContainer.add(result);
      buttonContainer.add(playAgain);
      buttonContainer.add(exitGame);
      
      // Update the layout of the button container to reflect any changes
      buttonContainer.revalidate();   
      // Repaint the button container to ensure it is visually updated 
      buttonContainer.repaint();   
      // Add the button container to the main frame
      frame.add(buttonContainer, BorderLayout.CENTER);
   }
   
}